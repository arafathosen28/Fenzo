export default function AdminHome() {
  return (
    <div className="glass rounded-2xl p-6">
      <h2 className="text-xl mb-2">Dashboard</h2>
      <p className="text-white/70">Use sidebar navigation to manage products and orders.</p>
    </div>
  )
}
